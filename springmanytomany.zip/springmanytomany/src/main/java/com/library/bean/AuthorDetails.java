package com.library.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Authors")
public class AuthorDetails 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int authorId;
	private String authorName;
	private int authorAge;
	private String authorAddress;
	private String authorMailId;
	
	@ManyToMany(fetch =FetchType.LAZY,cascade = {CascadeType.MERGE,CascadeType.DETACH,CascadeType.PERSIST,CascadeType.REFRESH})
	@JoinTable(name="authorBooks",joinColumns= {@JoinColumn(name="authorId")},
	            inverseJoinColumns= {@JoinColumn(name="isbin")} )
	@JsonIgnore 
	private Set<BookDetails> books=new HashSet<>();
	public AuthorDetails(int authorId, String authorName) {
		super();
		this.authorId = authorId;
		this.authorName = authorName;
	}	


}
