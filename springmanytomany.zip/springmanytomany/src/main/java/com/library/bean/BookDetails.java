package com.library.bean;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
@Table(name="Books")
public class BookDetails 
{
    @Id
	private int isbin;
	private String bookTitle;
	private String bookPublisher;
	private int bookLength;
	@ManyToMany(fetch =FetchType.LAZY, cascade = {CascadeType.MERGE,CascadeType.DETACH,CascadeType.PERSIST,CascadeType.REFRESH},mappedBy = "books")
	@JsonIgnore 
    private Set<AuthorDetails> authors=new HashSet<>();
	public BookDetails(int isbin, String bookTitle) {
		super();
		this.isbin = isbin;
		this.bookTitle = bookTitle;
	}
	


	
}
