package com.library.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.library.bean.BookDetails;
import com.library.service.BookService;

@RestController
public class BookController 
{

	@Autowired
	private BookService bs;
	
	@GetMapping("/books")
	public Set<BookDetails> getAllBooks()
	{
		return bs.getAllBooks();		
	}
	
	@PostMapping("/books")
	public void createBook(@RequestBody BookDetails books)
	{
		bs.createBook(books);
	}
	
	@PutMapping("/books/{isbin}")
	public void updateBook(@PathVariable("isbin") int isbin,@RequestBody BookDetails books )
	{
		bs.updateBook(isbin,books);
	}
	
	@DeleteMapping("/books/{isbin}")
	public void DeleteBook(@PathVariable("isbin") int isbin)
	{
		bs.deleteBook(isbin);
	}
		
}
