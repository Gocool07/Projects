package com.library.controller;

import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.library.bean.AuthorDetails;
import com.library.service.AuthorService;
@RestController
public class AuthorController
{

	@Autowired
	private AuthorService as;
	
	@GetMapping("/authors")
	public Set<AuthorDetails> getAllAuthors()
	{
		return as.getAllAuthors();		
	}
	
	@PostMapping("/authors")
	public void createAuthor(@RequestBody AuthorDetails authors)
	{
		as.createAuthor(authors);
	}
	
	@PutMapping("/authors/{authorId}")
	public void updateBook(@PathVariable("authorId") int authorId,@RequestBody AuthorDetails authors )
	{
		as.updateAuthor(authorId,authors);
	}
	
	@DeleteMapping("/authors/{authorId}")
	public void DeleteAuthor(@PathVariable("authorId") int authorId)
	{
		as.deleteAuthor(authorId);
	}
		
}
