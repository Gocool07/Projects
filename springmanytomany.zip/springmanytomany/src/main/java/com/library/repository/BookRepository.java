package com.library.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.library.bean.BookDetails;

public interface BookRepository extends JpaRepository<BookDetails,Integer> 
{
}
