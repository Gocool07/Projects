package com.library.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.bean.AuthorDetails;
import com.library.repository.AuthorRepository;

@Service
public class AuthorService 
{

	
	@Autowired
	public AuthorRepository authorRep;
	
	public Set<AuthorDetails> getAllAuthors()
	{
		Set<AuthorDetails> authors=new HashSet<>();
		authorRep.findAll().forEach(authors::add);
		return authors;
	}
		
	public AuthorDetails getauthorsbyId(int authorId)
	{
		return authorRep.findById(authorId).get();
	}	
	
	public void createAuthor(AuthorDetails author)
	{
		authorRep.save(author);
	}
	
	public void updateAuthor(int authorId,AuthorDetails author)
	{
		authorRep.save(author);
	}
	
	public void deleteAuthor(int authorId)
	{
		authorRep.deleteById(authorId);
	}

}
