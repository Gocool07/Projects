package com.library.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.library.bean.BookDetails;
import com.library.repository.BookRepository;

@Service
public class BookService 
{

	@Autowired
	public BookRepository bookRep;
	
	public Set<BookDetails> getAllBooks()
	{
	    Set<BookDetails> books=new HashSet<>();
		bookRep.findAll().forEach(books::add);
		return books;
	}
	
	public BookDetails getbookbyId(int isbin)
	{
		return bookRep.findById(isbin).get();
	}	
	
	public void createBook(BookDetails book)
	{
		bookRep.save(book);
	}
	
	public void updateBook(int isbin,BookDetails book)
	{
		bookRep.save(book);
	}
	
	public void deleteBook(int isbin)
	{
		bookRep.deleteById(isbin);
	}

}
