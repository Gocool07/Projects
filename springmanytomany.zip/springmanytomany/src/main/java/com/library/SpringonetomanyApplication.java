package com.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringonetomanyApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(SpringonetomanyApplication.class, args);
	}

}
