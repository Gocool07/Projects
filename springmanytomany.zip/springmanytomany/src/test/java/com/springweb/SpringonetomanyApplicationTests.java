package com.springweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringonetomanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
