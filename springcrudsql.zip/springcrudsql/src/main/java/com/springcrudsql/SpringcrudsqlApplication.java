package com.springcrudsql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringcrudsqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringcrudsqlApplication.class, args);
	}

}
